
import React, { useEffect, useRef, useState } from "react";
import QRCodeStyling from "qr-code-styling";
import "./App.css";

const qrCode = new QRCodeStyling({
  width: 300,
  height: 300,
  type: "canvas",
  data: "https://backend.com/123",
  imageOptions: {
    hideBackgroundDots: true,
    imageSize: 0.3,
    margin: 0
  },
  dotsOptions: {
    color: "#101a35",
    type: "square"
  },
  backgroundOptions: {
    color: "#ffffff"
  },
  cornersSquareOptions: {
    color: "#101a35",
    type: "square"
  },
  cornersDotOptions: {
    color: "#101a35",
    type: "square"
  },
  qrOptions: {
    typeNumber: 8,
    mode: "Byte",
    errorCorrectionLevel: "H"
  }
});

export default function QRGenerator() {
  const qrRef = useRef(null);
  const [id, setId] = useState("123");

  useEffect(() => {
    if (!qrRef.current) return;

    qrCode.append(qrRef.current);
  }, []);

  useEffect(() => {
    qrCode.update({
      data: `https://backend.com/${id}`
    });
  }, [id]);

  const downloadQR = () => {
    qrCode.download({
      name: `QR-${id}`,
      extension: "png"
    });
  };

  return (
    <div className="qr-page">
      <div className="qr-card">

        <h2>QR Code Generator</h2>

        <label>Enter ID</label>

        <input
          value={id}
          onChange={(e) => setId(e.target.value)}
          placeholder="Enter ID"
        />

        <div className="qr-preview">
          <div ref={qrRef}></div>
        </div>

        <p>https://backend.com/{id}</p>

        <button
          onClick={downloadQR}
          disabled={!id.trim()}
        >
          Download QR Code
        </button>

      </div>
    </div>
  );
}
